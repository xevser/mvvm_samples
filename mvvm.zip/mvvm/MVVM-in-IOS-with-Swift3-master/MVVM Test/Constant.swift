//
//  Constant.swift
//  MVVM Test
//
//  Created by me on 8/29/17.
//  Copyright © 2017 universe. All rights reserved.
//

import Foundation
import UIKit

let RANDOM_USER_URL = "http://api.randomuser.me/?results=50&nat=e"
let GITHUB_URL = ""
let SHADOW_GRY: CGFloat = 120.0 / 255.0


typealias DownloadComplete = () -> ()
