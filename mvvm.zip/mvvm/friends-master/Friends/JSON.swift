//
//  JSON.swift
//  Friends
//
//  Created by Jussi Suojanen on 04/02/17.
//  Copyright © 2017 Jimmy. All rights reserved.
//

typealias JSON = Dictionary<String, Any>
