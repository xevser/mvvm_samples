//
//  TestFriendViewFramework.h
//  TestFriendViewFramework
//
//  Created by Jussi Suojanen on 27/01/2018.
//  Copyright © 2018 Jimmy. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TestFriendViewFramework.
FOUNDATION_EXPORT double TestFriendViewFrameworkVersionNumber;

//! Project version string for TestFriendViewFramework.
FOUNDATION_EXPORT const unsigned char TestFriendViewFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFriendViewFramework/PublicHeader.h>
