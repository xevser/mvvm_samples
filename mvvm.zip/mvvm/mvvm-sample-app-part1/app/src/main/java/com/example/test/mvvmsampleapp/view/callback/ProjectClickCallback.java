package com.example.test.mvvmsampleapp.view.callback;

import com.example.test.mvvmsampleapp.service.model.Project;

public interface ProjectClickCallback {
    void onClick(Project project);
}
