//
//  ALAccordionSectionViewController.swift
//  ALAccordion
//
//  Created by Sam Williams on 10/04/2015.
//  Copyright (c) 2015 Alliants Ltd. All rights reserved.
//
//  http://alliants.com
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double ALAccordionVersionNumber;
FOUNDATION_EXPORT const unsigned char ALAccordionVersionString[];
