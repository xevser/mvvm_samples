# Changelog

## Version 2.1.0
- Added completion handlers after expanding or collapsing cell.

## Version 2.0.1
- Migrated to Swift 4 and Xcode 9.1

## Version 2.0.0

- Updated code for Swift 3
- Updated project for Xcode 8.3.3
- Improvements and refactoring
- Migrated to dynamic framework with example project

## Version 1.0.3

- Minor changes

## Version 1.0.2

- Minor changes

## Version 1.0.1

- Minor changes

## Version 1.0.0

- Initial version
