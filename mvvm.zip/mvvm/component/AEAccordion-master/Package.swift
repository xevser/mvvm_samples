/**
 *  https://github.com/tadija/AEAccordion
 *  Copyright (c) Marko Tadić 2015-2018
 *  Licensed under the MIT license. See LICENSE file.
 */

import PackageDescription

let package = Package(
    name: "AEAccordion"
)
