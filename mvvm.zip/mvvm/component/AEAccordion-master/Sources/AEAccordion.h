/**
 *  https://github.com/tadija/AEAccordion
 *  Copyright (c) Marko Tadić 2015-2018
 *  Licensed under the MIT license. See LICENSE file.
 */

#import <UIKit/UIKit.h>

FOUNDATION_EXPORT double AEAccordionVersionNumber;
FOUNDATION_EXPORT const unsigned char AEAccordionVersionString[];
