//
//  AppDelegate.swift
//  AEAccordionExample
//
//  Created by Marko Tadic on 6/27/15.
//  Copyright © 2015 AE. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
}
