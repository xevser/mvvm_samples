//
//  MultiAutoCompleteTextSwift.h
//  MultiAutoCompleteTextSwift
//
//  Created by Tatsuhiko Shimomura on 2016/09/25.
//  Copyright © 2016年 Tatsuhiko Shimomura. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MultiAutoCompleteTextSwift.
FOUNDATION_EXPORT double MultiAutoCompleteTextSwiftVersionNumber;

//! Project version string for MultiAutoCompleteTextSwift.
FOUNDATION_EXPORT const unsigned char MultiAutoCompleteTextSwiftVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MultiAutoCompleteTextSwift/PublicHeader.h>


