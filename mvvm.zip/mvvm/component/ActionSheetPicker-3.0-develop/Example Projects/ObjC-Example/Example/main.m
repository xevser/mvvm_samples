//
//  main.m
//  ActionSheetPicker
//
//  Created by S3166992 on 6/01/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import "ActionSheetPickerAppDelegate.h"

int main(int argc, char *argv[]) {
    
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([ActionSheetPickerAppDelegate class]));
        return retVal;
    }
}
